
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

exports.addMedia = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError("unauthenticated", "Non autorisé");
  const { title, url, type, isTop } = data;
  await db.collection("ia_gallery").add({
    title, url, type, isTop: !!isTop, createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return { status: "success" };
});
